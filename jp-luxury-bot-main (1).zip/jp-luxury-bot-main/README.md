# JP Luxury Watcher

Bot, který sleduje japonský Mercari (největší japonský bazar s použitým
zbožím) pro Louis Vuitton do 100 € a nové nabídky posílá jako jednoduché
upozornění na Discord — název produktu, cena a doba v nabídce, s přímým
odkazem.

Sledovaná značka: Louis Vuitton, max. cena 100 € (lze upravit v `config.py`).

Kontrola probíhá každých 10 minut, zdarma, bez nutnosti vlastního serveru —
běží na GitHub Actions.

## Jak to funguje

- `main.py` projede pro Louis Vuitton 3 dotazy (kabelka / peněženka / doplněk)
  na Mercari přes knihovnu [mercapi](https://github.com/take-kun/mercapi).
- Nové položky (dle ID, které bot ještě neviděl) do 100 € pošle na Discord
  webhook — jen název, cena a doba v nabídce.
- Stav (co už bot viděl) se ukládá do `state.json`, který si GitHub Actions
  po každém běhu sám commitne zpět do repozitáře.

## Nasazení (nejjednodušší varianta — GitHub Actions, zdarma)

**1. Vytvoř si Discord webhook**
   V Discordu: Nastavení kanálu → Integrace → Webhooky → Nový webhook →
   zkopíruj URL.

**2. Vytvoř si GitHub účet a nový repozitář** (pokud ho ještě nemáš)
   Může být klidně soukromý (private).

**3. Nahraj do repozitáře tyto soubory**
   Buď přes web (Add file → Upload files) — nahraj celý obsah této složky
   se zachováním struktury (hlavně `.github/workflows/monitor.yml` musí
   zůstat v této cestě), nebo přes git:
   ```
   git init
   git add .
   git commit -m "init"
   git branch -M main
   git remote add origin https://github.com/TVOJE_JMENO/TVUJ_REPO.git
   git push -u origin main
   ```

**4. Přidej webhook URL jako "Secret"**
   V repozitáři: Settings → Secrets and variables → Actions → New repository
   secret → Name: `DISCORD_WEBHOOK_URL` → Value: (URL z kroku 1).

**5. Hotovo**
   Workflow se spustí automaticky každých 10 minut. Manuální test:
   záložka **Actions** → **JP Luxury Watcher** → **Run workflow**.

## Úpravy

- **Přidat/odebrat značku nebo kategorii** → uprav `BRANDS` / `CATEGORY_WORDS`
  v `config.py`.
- **Změnit cenový limit** → `MAX_PRICE_EUR` v `config.py` (aktuálně 100 €).
- **Změnit frekvenci kontrol** → uprav `cron` v
  `.github/workflows/monitor.yml` (GitHub cron min. interval je cca 5 minut,
  ale při vysoké zátěži GitHubu se skutečné spuštění může o pár minut
  zpozdit — to je omezení platformy, ne bota).

## Důležité poznámky

- `mercapi` je **neoficiální** knihovna reverzně inženýrovaná z Mercari
  webu/appky. Mercari čas od času mění zabezpečení API, což může knihovnu
  dočasně rozbít — pokud bot přestane fungovat, zkontroluj repozitář
  [take-kun/mercapi](https://github.com/take-kun/mercapi), jestli nevyšla
  nová verze (`pip install -U mercapi`).
- Automatizované dotazování cizí služby může být v rozporu s obchodními
  podmínkami Mercari. Nastav si přiměřenou frekvenci (10 min je stále
  rozumné) a používej bota jen pro osobní účel (sledování nabídek), ne
  pro hromadné stahování dat.
- Pole jako "stav zboží" nebo "vytvořeno" nemusí být u každé položky
  k dispozici — bot to ošetřuje a v takovém případě zobrazí "neuvedeno" /
  "neznámo" místo pádu.

## Rozšíření na další tržiště (Yahoo Auctions Japan, Rakuma, 2nd Street…)

Aktuálně bot pokrývá jen Mercari Japan (nejrelevantnější a nejlikvidnější
trh pro tento typ zboží). Přidání dalšího tržiště znamená napsat obdobnou
funkci jako `fetch_query()` v `main.py`, která vrátí seznam položek ve
stejném formátu (`id`, `name`, `price`, `url`, `condition`, `created`,
`thumbnail`) — zbytek pipeline (dedup, cenový filtr, Discord) je
znovupoužitelný.
Napiš, pokud chceš pomoct s konkrétním tržištěm.
